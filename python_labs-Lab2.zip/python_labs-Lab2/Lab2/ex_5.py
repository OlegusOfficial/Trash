from time import *
from random import randint
from librip.ctxmngrs import timer


with timer():
   sleep(5.5)
